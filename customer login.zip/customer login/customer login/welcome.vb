﻿Public Class frmWelcome
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        frmCreateOrder.Show()
    End Sub
End Class