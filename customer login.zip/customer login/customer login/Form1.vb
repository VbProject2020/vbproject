﻿Public Class frmCustomerLogin
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Customerlogin1DataSet.customer_login' table. You can move, or remove it, as needed.
        Me.Customer_loginTableAdapter.Fill(Me.Customerlogin1DataSet.customer_login)
        'TODO: This line of code loads data into the 'Customerlogin1DataSet.customer_login' table. You can move, or remove it, as needed.
        Me.Customer_loginTableAdapter.Fill(Me.Customerlogin1DataSet.customer_login)
        grpCreate.Visible = False

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim strUser As String = txtUser.Text
        Dim strPassword As String = txtPassword.Text

        Dim query1 = From username In Customerlogin1DataSet.customer_login
                     Select username.username, username.password Where username = strUser AndAlso password = strPassword

        If query1.Count = 1 Then
            MessageBox.Show("Yes")
        Else
            MessageBox.Show("No")
        End If

    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click


        Try
            BindingSource1.EndEdit()
            Customer_loginTableAdapter.Update(Me.Customerlogin1DataSet.customer_login)
            MessageBox.Show("Success")
        Catch ex As Exception
            MessageBox.Show("Error")

        End Try
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        grpCreate.Visible = True

        BindingSource1.AddNew()
    End Sub
End Class
